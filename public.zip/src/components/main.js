import React, { Component } from 'react';

import './main.css';
class AdderSub extends React.Component{
    render() {
        return (
            <div >
                <button id="btn" onClick={this.props.inc}>Add</button>
                <button id="btn" onClick={this.props.dec}>Minus</button>
            </div>
        );
    }
}
export default AdderSub;    