import React from "react";

class Display extends React.Component {
   render() {
       return (
           <div>{this.props.clicks}</div>
       );
   }
}
export default Display;