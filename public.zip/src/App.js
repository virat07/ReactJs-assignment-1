import React, { Component } from 'react';
import './App.css';
import AdderSub from './components/main';

import Display from './components/display'

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      clicks: 0
    };
}


increment() {
  this.setState({ clicks: this.state.clicks + 1 });
}

decrement() {
  this.setState({ clicks: this.state.clicks - 1 });
}
render() {
  return (
    <div>
      <div id="display"><Display clicks={this.state.clicks} /></div>
      <div ><AdderSub inc={this.increment.bind(this)} dec={this.decrement.bind(this)} /></div>

    </div>
  );
}
}

export default App;
